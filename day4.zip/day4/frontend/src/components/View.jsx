import React, { useState } from 'react'
import axios from 'axios'

const View = () => {
    const [users, setUsers] = useState([])
    const handleviews()

  return (
    <div>View</div>
  )
}

export default View